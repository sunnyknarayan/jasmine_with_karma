describe("Email validation",function(){
  it("Regular Email" , function(){
    expect(checkEmail("nanda@gmail.com")).toBe(true);
  })
  it("Invalid Email" , function(){
    
    expect(checkEmail("nanda@gmail.com")).toBe(true);
  })
  })