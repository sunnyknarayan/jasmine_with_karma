describe("addition", function(){
    it("2 numbers", function(){
      expect(50+90).toBe(150);
    })
    it("2 numbers -ve" , function(){
      expect(-20+10).not.toBe(-30);
    })
    it("2 numbers with 0",function(){
      expect(0+25).toBe(25);
    })
  })