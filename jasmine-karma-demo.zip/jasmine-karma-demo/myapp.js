/**
 * http://usejsdoc.org/
 */
var myApp = angular.module("myApp",[]);

/*myApp.controller("hellocntrl", function($scope) {
	$scope.text = "Hello!";
});*/

myApp.controller('hellocntrl', function($scope) {
	$scope.data = "Hi!";
});

